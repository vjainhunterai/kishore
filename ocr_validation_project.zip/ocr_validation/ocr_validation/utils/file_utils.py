import os
from datetime import datetime


def write_validation_outputs(
    matched_df,
    unmatched_df,
    output_directory,
    source_file_name,
    run_id,
    logger,
):
    os.makedirs(output_directory, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_name = os.path.splitext(source_file_name)[0]
    suffix = run_id[-8:]

    matched_file = os.path.join(
        output_directory,
        f"{base_name}_matched_{timestamp}_{suffix}.xlsx"
    )

    unmatched_file = os.path.join(
        output_directory,
        f"{base_name}_unmatched_{timestamp}_{suffix}.xlsx"
    )

    matched_df.to_excel(
        matched_file, index=False, engine="openpyxl"
    )
    unmatched_df.to_excel(
        unmatched_file, index=False, engine="openpyxl"
    )

    logger.info("Matched output: %s", matched_file)
    logger.info("Unmatched output: %s", unmatched_file)

    return matched_file, unmatched_file
