import re
import uuid
from datetime import datetime


def generate_run_id() -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"OCR_{timestamp}_{uuid.uuid4().hex[:8]}"


def validate_vendor_name(vendor_name: str) -> str:
    vendor_name = vendor_name.strip()

    if not vendor_name:
        raise ValueError("Vendor name cannot be empty.")

    if not re.fullmatch(r"[A-Za-z0-9_]+", vendor_name):
        raise ValueError(
            "Vendor name can contain only letters, numbers and underscore."
        )

    return vendor_name


def get_stage_table_name(vendor_name: str) -> str:
    return f"{validate_vendor_name(vendor_name)}_OCR_Data"
