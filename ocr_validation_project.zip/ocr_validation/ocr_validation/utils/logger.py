import logging
import os
from datetime import datetime


def get_logger(job_name: str, log_directory: str) -> logging.Logger:
    os.makedirs(log_directory, exist_ok=True)

    timestamp = datetime.now().strftime("%d%m%Y%H%M%S")
    log_file = os.path.join(
        log_directory,
        f"{job_name}_{timestamp}_info.log"
    )

    logger = logging.getLogger(job_name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    console_handler = logging.StreamHandler()

    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
