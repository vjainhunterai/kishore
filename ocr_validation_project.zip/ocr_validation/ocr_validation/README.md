# OCR Validation Framework

Production-oriented Python framework for validating OCR invoice data against ERP data in MySQL.

## Flow

Input Template -> OCR Excel -> Standardisation -> MySQL Stage -> ERP Query -> ERP Standardisation -> Invoice Number -> Date -> Amount -> Matched/Unmatched Excel

## Input Template

Required columns:

- file_name
- vendor_name
- column_names
- date (optional)

Example:

| file_name | vendor_name | column_names | date |
|---|---|---|---|
| ABC_invoice.xlsx | ABC | invoice_number,invoice_date,amount | 2026-09-18 |

If date is blank, ERP is queried without a date filter.

## Setup

1. Create a Python virtual environment.
2. Install:
   `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Update database and folder configuration.
5. Run `sql/create_audit_tables.sql` in MySQL.
6. Update the ERP table/column configuration.
7. Update the template path in `ocr_validation_job.py`.
8. Run the job.

## Stage Table

The stage table is:

`<vendor_name>_OCR_Data`

Records include `run_id`, source file information and load timestamp.

## Output

Two Excel files are generated:

- matched_records
- unmatched_records

Unmatched records include:

- validation_status
- failure_code
- failure_reason

## Important

The current implementation assumes the OCR file has these business columns:

- invoice_number
- invoice_date
- amount

Vendor-specific column mapping can be added later to make these fully metadata-driven.
