import pandas as pd

REQUIRED_COLUMNS = {"file_name", "vendor_name", "column_names"}


def read_input_template(template_path: str) -> dict:
    df = pd.read_excel(template_path, engine="openpyxl")

    if df.empty:
        raise ValueError("Input template contains no records.")

    df.columns = df.columns.astype(str).str.strip().str.lower()

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing template columns: {sorted(missing)}")

    if len(df) != 1:
        raise ValueError("Input template should contain exactly one configuration row.")

    row = df.iloc[0]

    file_name = str(row["file_name"]).strip()
    vendor_name = str(row["vendor_name"]).strip()
    column_names = str(row["column_names"]).strip()

    if not file_name:
        raise ValueError("file_name cannot be empty.")
    if not vendor_name:
        raise ValueError("vendor_name cannot be empty.")
    if not column_names:
        raise ValueError("column_names cannot be empty.")

    date_value = row.get("date")
    if date_value is None or pd.isna(date_value) or str(date_value).strip() == "":
        processing_date = None
    else:
        parsed = pd.to_datetime(date_value, errors="coerce")
        if pd.isna(parsed):
            raise ValueError(f"Invalid processing date: {date_value}")
        processing_date = parsed.strftime("%Y-%m-%d")

    return {
        "file_name": file_name,
        "vendor_name": vendor_name,
        "column_names": column_names,
        "date": processing_date,
    }
