import os
import pandas as pd


def read_ocr_file(input_directory, file_name, column_names, logger):
    file_path = os.path.join(input_directory, file_name)

    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"OCR file not found: {file_path}")

    logger.info("Reading OCR file: %s", file_path)

    extension = os.path.splitext(file_name)[1].lower()
    if extension not in [".xlsx", ".xls"]:
        raise ValueError(f"Only Excel files are supported: {file_name}")

    df = pd.read_excel(file_path, engine="openpyxl")

    if df.empty:
        raise ValueError(f"OCR file is empty: {file_name}")

    df.columns = df.columns.astype(str).str.strip().str.lower()

    requested_columns = [
        c.strip().lower() for c in column_names.split(",") if c.strip()
    ]

    missing = [c for c in requested_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Required OCR columns are missing: {missing}")

    required = {"invoice_number", "invoice_date", "amount"}
    missing_business = required - set(df.columns)
    if missing_business:
        raise ValueError(
            f"Required validation columns missing from OCR file: {sorted(missing_business)}"
        )

    logger.info("OCR records read successfully: %s", len(df))
    return df
