import pandas as pd

df = pd.DataFrame([{
    "file_name": "ABC_invoice.xlsx",
    "vendor_name": "ABC",
    "column_names": "invoice_number,invoice_date,amount",
    "date": "2026-09-18",
}])

df.to_excel("input_template.xlsx", index=False)
print("Created input_template.xlsx")
