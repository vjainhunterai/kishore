CREATE TABLE IF NOT EXISTS ocr_validation_execution_log
(
    run_id VARCHAR(100) NOT NULL,
    job_name VARCHAR(100) NOT NULL,
    vendor_name VARCHAR(255),
    source_file_name VARCHAR(500),
    processing_date DATE NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NULL,
    ocr_record_count INT DEFAULT 0,
    erp_record_count INT DEFAULT 0,
    matched_record_count INT DEFAULT 0,
    unmatched_record_count INT DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    error_message TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (run_id)
);
