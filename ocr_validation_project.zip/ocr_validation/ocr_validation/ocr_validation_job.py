from datetime import datetime

from config.config import (
    OCR_INPUT_PATH,
    OCR_OUTPUT_PATH,
    OCR_LOG_PATH,
    ERP_TABLE,
    ERP_INVOICE_NUMBER_COLUMN,
    ERP_INVOICE_DATE_COLUMN,
    ERP_AMOUNT_COLUMN,
    AMOUNT_TOLERANCE,
    validate_config,
)

from db.database import get_database_engine
from readers.input_template_reader import read_input_template
from readers.ocr_reader import read_ocr_file

from services.staging_service import (
    standardize_ocr_data,
    load_to_stage,
)
from services.erp_service import (
    read_erp_data,
    standardize_erp_data,
)
from services.validation_service import validate_ocr_against_erp
from services.audit_service import insert_execution_log

from utils.logger import get_logger
from utils.validation_utils import (
    generate_run_id,
    get_stage_table_name,
)
from utils.file_utils import write_validation_outputs


JOB_NAME = "OCR_VALIDATION"


def run_ocr_validation(template_path: str):

    start_time = datetime.now()
    run_id = generate_run_id()

    logger = get_logger(
        f"{JOB_NAME}_{run_id}",
        OCR_LOG_PATH,
    )

    engine = None
    ocr_count = 0
    erp_count = 0
    matched_count = 0
    unmatched_count = 0

    vendor_name = ""
    file_name = ""
    processing_date = None

    try:
        logger.info("=" * 70)
        logger.info("OCR VALIDATION JOB STARTED")
        logger.info("Run ID: %s", run_id)

        # 1. Configuration
        validate_config()

        # 2. Input template
        logger.info("Reading input template: %s", template_path)
        params = read_input_template(template_path)

        file_name = params["file_name"]
        vendor_name = params["vendor_name"]
        column_names = params["column_names"]
        processing_date = params["date"]

        logger.info("Source file: %s", file_name)
        logger.info("Vendor: %s", vendor_name)
        logger.info("Columns: %s", column_names)

        if processing_date:
            logger.info(
                "ERP query condition: DATE FILTER = %s",
                processing_date,
            )
        else:
            logger.info(
                "ERP query condition: NO DATE FILTER"
            )

        # 3. Stage table
        stage_table = get_stage_table_name(vendor_name)
        logger.info("Stage table: %s", stage_table)

        # 4. DB connection
        logger.info("Creating database connection.")
        engine = get_database_engine()

        # 5. OCR read
        ocr_df = read_ocr_file(
            OCR_INPUT_PATH,
            file_name,
            column_names,
            logger,
        )
        ocr_count = len(ocr_df)

        # 6. OCR standardisation
        ocr_df = standardize_ocr_data(
            ocr_df,
            logger,
        )

        # 7. Stage load
        load_to_stage(
            df=ocr_df,
            table_name=stage_table,
            engine=engine,
            run_id=run_id,
            file_name=file_name,
            vendor_name=vendor_name,
            logger=logger,
        )

        # 8. ERP read
        erp_df = read_erp_data(
            engine=engine,
            erp_table=ERP_TABLE,
            invoice_number_column=ERP_INVOICE_NUMBER_COLUMN,
            invoice_date_column=ERP_INVOICE_DATE_COLUMN,
            amount_column=ERP_AMOUNT_COLUMN,
            processing_date=processing_date,
            logger=logger,
        )

        # 9. ERP standardisation
        erp_df = standardize_erp_data(
            erp_df,
            logger,
        )
        erp_count = len(erp_df)

        # 10. ERP validation
        matched_df, unmatched_df = validate_ocr_against_erp(
            ocr_df=ocr_df,
            erp_df=erp_df,
            amount_tolerance=AMOUNT_TOLERANCE,
            logger=logger,
        )

        matched_count = len(matched_df)
        unmatched_count = len(unmatched_df)

        # 11. Output
        matched_file, unmatched_file = write_validation_outputs(
            matched_df=matched_df,
            unmatched_df=unmatched_df,
            output_directory=OCR_OUTPUT_PATH,
            source_file_name=file_name,
            run_id=run_id,
            logger=logger,
        )

        # 12. Audit
        end_time = datetime.now()

        insert_execution_log(
            engine=engine,
            run_id=run_id,
            job_name=JOB_NAME,
            vendor_name=vendor_name,
            source_file_name=file_name,
            processing_date=processing_date,
            start_time=start_time,
            end_time=end_time,
            ocr_count=ocr_count,
            erp_count=erp_count,
            matched_count=matched_count,
            unmatched_count=unmatched_count,
            status="SUCCESS",
        )

        duration = (end_time - start_time).total_seconds()

        logger.info("=" * 70)
        logger.info("OCR VALIDATION SUMMARY")
        logger.info("Run ID           : %s", run_id)
        logger.info("OCR records      : %s", ocr_count)
        logger.info("ERP records      : %s", erp_count)
        logger.info("Matched records  : %s", matched_count)
        logger.info("Unmatched records: %s", unmatched_count)
        logger.info("Execution time   : %.2f seconds", duration)
        logger.info("Matched output   : %s", matched_file)
        logger.info("Unmatched output : %s", unmatched_file)
        logger.info("STATUS           : SUCCESS")
        logger.info("=" * 70)

        return {
            "status": "SUCCESS",
            "run_id": run_id,
            "ocr_count": ocr_count,
            "erp_count": erp_count,
            "matched_count": matched_count,
            "unmatched_count": unmatched_count,
            "matched_file": matched_file,
            "unmatched_file": unmatched_file,
            "duration_seconds": duration,
        }

    except Exception as exc:
        end_time = datetime.now()

        logger.exception("OCR validation job failed.")

        if engine is not None:
            try:
                insert_execution_log(
                    engine=engine,
                    run_id=run_id,
                    job_name=JOB_NAME,
                    vendor_name=vendor_name,
                    source_file_name=file_name,
                    processing_date=processing_date,
                    start_time=start_time,
                    end_time=end_time,
                    ocr_count=ocr_count,
                    erp_count=erp_count,
                    matched_count=matched_count,
                    unmatched_count=unmatched_count,
                    status="FAILED",
                    error_message=str(exc),
                )
            except Exception:
                logger.exception(
                    "Unable to write failure audit."
                )

        raise


if __name__ == "__main__":
    TEMPLATE_PATH = (
        "C:/HunterAI/OCR/input/input_template.xlsx"
    )

    run_ocr_validation(TEMPLATE_PATH)
