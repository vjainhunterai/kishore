import pandas as pd


def validate_ocr_against_erp(
    ocr_df: pd.DataFrame,
    erp_df: pd.DataFrame,
    amount_tolerance: float,
    logger,
):
    logger.info("Starting OCR vs ERP validation.")

    ocr = ocr_df.copy()
    erp = erp_df.copy()

    ocr["invoice_number"] = (
        ocr["invoice_number"]
        .replace({"": pd.NA, "NAN": pd.NA, "NONE": pd.NA})
    )

    # ERP duplicate protection: prevent many-to-many merge explosion.
    erp_duplicate_mask = erp["invoice_number"].duplicated(keep=False)
    duplicate_erp = erp[erp_duplicate_mask]

    if not duplicate_erp.empty:
        logger.warning(
            "Duplicate invoice numbers found in ERP: %s",
            duplicate_erp["invoice_number"].nunique(),
        )

    # For now, mark duplicate ERP keys as ambiguous and exclude them
    # from the normal lookup.
    erp_counts = erp["invoice_number"].value_counts(dropna=True)
    duplicate_keys = set(erp_counts[erp_counts > 1].index)

    erp_lookup = erp[
        ~erp["invoice_number"].isin(duplicate_keys)
    ][["invoice_number", "invoice_date", "amount"]].copy()

    ocr_duplicate_mask = ocr["invoice_number"].duplicated(keep=False)
    if ocr[ocr_duplicate_mask].shape[0] > 0:
        logger.warning(
            "Duplicate invoice numbers found in OCR: %s",
            ocr.loc[ocr_duplicate_mask, "invoice_number"].nunique(),
        )

    result = ocr.merge(
        erp_lookup,
        on="invoice_number",
        how="left",
        suffixes=("_ocr", "_erp"),
        indicator=True,
    )

    # Identify ERP duplicate keys separately.
    result["erp_duplicate"] = result["invoice_number"].isin(duplicate_keys)

    invoice_not_found = (
        (result["_merge"] == "left_only")
        & ~result["erp_duplicate"]
    )

    erp_duplicate = result["erp_duplicate"]

    date_mismatch = (
        (result["_merge"] == "both")
        & ~result["erp_duplicate"]
        & (
            result["invoice_date_ocr"]
            != result["invoice_date_erp"]
        )
    )

    amount_difference = (
        result["amount_ocr"] - result["amount_erp"]
    ).abs()

    amount_mismatch = (
        (result["_merge"] == "both")
        & ~result["erp_duplicate"]
        & (amount_difference > amount_tolerance)
    )

    passed = (
        (result["_merge"] == "both")
        & ~result["erp_duplicate"]
        & ~date_mismatch
        & ~amount_mismatch
    )

    result["validation_status"] = "FAILED"
    result["failure_code"] = None
    result["failure_reason"] = None

    result.loc[erp_duplicate, "failure_code"] = "ERP_DUPLICATE"
    result.loc[erp_duplicate, "failure_reason"] = (
        "Multiple ERP records found for invoice number"
    )

    result.loc[invoice_not_found, "failure_code"] = "INV_NOT_FOUND"
    result.loc[invoice_not_found, "failure_reason"] = (
        "Invoice number not found in ERP"
    )

    result.loc[date_mismatch, "failure_code"] = "DATE_MISMATCH"
    result.loc[date_mismatch, "failure_reason"] = (
        "Invoice date mismatch | OCR="
        + result.loc[date_mismatch, "invoice_date_ocr"].astype(str)
        + " | ERP="
        + result.loc[date_mismatch, "invoice_date_erp"].astype(str)
    )

    result.loc[amount_mismatch, "failure_code"] = "AMOUNT_MISMATCH"
    result.loc[amount_mismatch, "failure_reason"] = (
        "Invoice amount mismatch | OCR="
        + result.loc[amount_mismatch, "amount_ocr"].map(
            lambda x: f"{x:.2f}" if pd.notna(x) else "NULL"
        )
        + " | ERP="
        + result.loc[amount_mismatch, "amount_erp"].map(
            lambda x: f"{x:.2f}" if pd.notna(x) else "NULL"
        )
    )

    result.loc[passed, "validation_status"] = "PASSED"

    matched = result[result["validation_status"] == "PASSED"].copy()
    unmatched = result[result["validation_status"] == "FAILED"].copy()

    for frame in (matched, unmatched):
        frame.drop(
            columns=["_merge", "erp_duplicate"],
            inplace=True,
            errors="ignore",
        )

    logger.info("Validation completed.")
    logger.info("Matched records: %s", len(matched))
    logger.info("Unmatched records: %s", len(unmatched))

    return matched, unmatched
