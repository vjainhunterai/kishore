import pandas as pd
from sqlalchemy import text
from sqlalchemy.engine import Engine


def read_erp_data(
    engine: Engine,
    erp_table: str,
    invoice_number_column: str,
    invoice_date_column: str,
    amount_column: str,
    processing_date: str | None,
    logger,
) -> pd.DataFrame:

    if processing_date:
        logger.info("ERP query mode: DATE FILTER = %s", processing_date)

        query = text(f"""
            SELECT
                `{invoice_number_column}` AS invoice_number,
                `{invoice_date_column}` AS invoice_date,
                `{amount_column}` AS amount
            FROM `{erp_table}`
            WHERE DATE(`{invoice_date_column}`) = :processing_date
        """)
        params = {"processing_date": processing_date}
    else:
        logger.info("ERP query mode: NO DATE FILTER")

        query = text(f"""
            SELECT
                `{invoice_number_column}` AS invoice_number,
                `{invoice_date_column}` AS invoice_date,
                `{amount_column}` AS amount
            FROM `{erp_table}`
        """)
        params = {}

    logger.info("Executing ERP query.")
    erp_df = pd.read_sql(query, engine, params=params)

    if erp_df.empty:
        logger.warning("ERP query returned zero records.")
    else:
        logger.info("ERP records retrieved: %s", len(erp_df))

    return erp_df


def standardize_erp_data(df: pd.DataFrame, logger) -> pd.DataFrame:
    result = df.copy()

    logger.info("Standardising ERP invoice number.")
    result["invoice_number"] = (
        result["invoice_number"].astype("string").str.strip().str.upper()
    )

    logger.info("Standardising ERP invoice date.")
    result["invoice_date"] = (
        pd.to_datetime(result["invoice_date"], errors="coerce")
        .dt.strftime("%Y-%m-%d")
    )

    logger.info("Standardising ERP amount.")
    result["amount"] = pd.to_numeric(
        result["amount"], errors="coerce"
    ).round(2)

    return result
