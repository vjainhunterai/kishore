import pandas as pd
from sqlalchemy.engine import Engine


def standardize_ocr_data(df: pd.DataFrame, logger) -> pd.DataFrame:
    result = df.copy()

    logger.info("Standardising OCR invoice number.")
    result["invoice_number"] = (
        result["invoice_number"].astype("string").str.strip().str.upper()
    )

    logger.info("Standardising OCR invoice date.")
    result["invoice_date"] = (
        pd.to_datetime(result["invoice_date"], errors="coerce", dayfirst=True)
        .dt.strftime("%Y-%m-%d")
    )

    logger.info("Standardising OCR amount.")
    result["amount"] = (
        pd.to_numeric(result["amount"], errors="coerce").round(2)
    )

    result["_source_row_number"] = range(2, len(result) + 2)
    return result


def load_to_stage(
    df: pd.DataFrame,
    table_name: str,
    engine: Engine,
    run_id: str,
    file_name: str,
    vendor_name: str,
    logger,
) -> int:
    stage_df = df.copy()

    stage_df.insert(0, "run_id", run_id)
    stage_df.insert(1, "source_file_name", file_name)
    stage_df.insert(2, "vendor_name", vendor_name)
    stage_df["load_timestamp"] = pd.Timestamp.now()

    logger.info("Loading %s records into stage table %s", len(stage_df), table_name)

    stage_df.to_sql(
        name=table_name,
        con=engine,
        if_exists="append",
        index=False,
        chunksize=5000,
        method="multi",
    )

    logger.info("Stage load completed. Records: %s", len(stage_df))
    return len(stage_df)
