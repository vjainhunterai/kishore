from datetime import datetime
from sqlalchemy import text
from sqlalchemy.engine import Engine


def insert_execution_log(
    engine: Engine,
    run_id: str,
    job_name: str,
    vendor_name: str,
    source_file_name: str,
    processing_date,
    start_time: datetime,
    end_time: datetime,
    ocr_count: int,
    erp_count: int,
    matched_count: int,
    unmatched_count: int,
    status: str,
    error_message: str | None = None,
):
    query = text("""
        INSERT INTO ocr_validation_execution_log
        (
            run_id, job_name, vendor_name, source_file_name,
            processing_date, start_time, end_time,
            ocr_record_count, erp_record_count,
            matched_record_count, unmatched_record_count,
            status, error_message
        )
        VALUES
        (
            :run_id, :job_name, :vendor_name, :source_file_name,
            :processing_date, :start_time, :end_time,
            :ocr_count, :erp_count, :matched_count, :unmatched_count,
            :status, :error_message
        )
    """)

    with engine.begin() as connection:
        connection.execute(query, {
            "run_id": run_id,
            "job_name": job_name,
            "vendor_name": vendor_name,
            "source_file_name": source_file_name,
            "processing_date": processing_date,
            "start_time": start_time,
            "end_time": end_time,
            "ocr_count": ocr_count,
            "erp_count": erp_count,
            "matched_count": matched_count,
            "unmatched_count": unmatched_count,
            "status": status,
            "error_message": error_message,
        })
