import os
from dotenv import load_dotenv

load_dotenv()

MYSQL_HOST = os.getenv("MYSQL_HOST")
MYSQL_PORT = os.getenv("MYSQL_PORT", "3306")
MYSQL_USER = os.getenv("MYSQL_USER")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE")

OCR_INPUT_PATH = os.getenv("OCR_INPUT_PATH")
OCR_OUTPUT_PATH = os.getenv("OCR_OUTPUT_PATH")
OCR_LOG_PATH = os.getenv("OCR_LOG_PATH")

ERP_TABLE = os.getenv("ERP_TABLE")
ERP_INVOICE_NUMBER_COLUMN = os.getenv("ERP_INVOICE_NUMBER_COLUMN", "invoice_number")
ERP_INVOICE_DATE_COLUMN = os.getenv("ERP_INVOICE_DATE_COLUMN", "invoice_date")
ERP_AMOUNT_COLUMN = os.getenv("ERP_AMOUNT_COLUMN", "amount")
AMOUNT_TOLERANCE = float(os.getenv("AMOUNT_TOLERANCE", "0.01"))


def validate_config():
    required = {
        "MYSQL_HOST": MYSQL_HOST,
        "MYSQL_USER": MYSQL_USER,
        "MYSQL_PASSWORD": MYSQL_PASSWORD,
        "MYSQL_DATABASE": MYSQL_DATABASE,
        "OCR_INPUT_PATH": OCR_INPUT_PATH,
        "OCR_OUTPUT_PATH": OCR_OUTPUT_PATH,
        "OCR_LOG_PATH": OCR_LOG_PATH,
        "ERP_TABLE": ERP_TABLE,
    }
    missing = [key for key, value in required.items() if not value]
    if missing:
        raise ValueError(f"Missing mandatory configuration: {missing}")
