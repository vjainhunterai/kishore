import re
from sqlalchemy import text


class SchemaManager:
    @staticmethod
    def safe_identifier(value):
        cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", str(value)).strip("_").lower()
        if not cleaned:
            raise ValueError("Could not create a valid SQL identifier")
        if cleaned[0].isdigit():
            cleaned = "c_" + cleaned
        return cleaned[:60]

    @staticmethod
    def quote_identifier(value):
        # Identifiers are validated before quoting.
        if not re.fullmatch(r"[A-Za-z0-9_]+", value):
            raise ValueError(f"Unsafe SQL identifier: {value}")
        return "`" + value + "`"

    def create_or_validate_staging_table(self, engine, file_name, columns):
        table_name = "stg_" + self.safe_identifier(file_name.rsplit(".", 1)[0])
        table_name = table_name[:64]
        q_table = self.quote_identifier(table_name)

        # Preserve original source values as TEXT to avoid losing leading zeros.
        column_defs = [
            f"{self.quote_identifier(self.safe_identifier(c))} LONGTEXT NULL"
            for c in columns
        ]
        column_defs.extend([
            "`_batch_id` VARCHAR(100) NOT NULL",
            "`_loaded_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)",
        ])
        create_sql = (
            f"CREATE TABLE IF NOT EXISTS {q_table} "
            f"({', '.join(column_defs)}, KEY `idx_batch_id` (`_batch_id`)) "
            "ENGINE=InnoDB"
        )

        with engine.begin() as conn:
            conn.execute(text(create_sql))
            existing = conn.execute(text(f"SHOW COLUMNS FROM {q_table}")).all()
            existing_names = {row[0] for row in existing}
            expected_names = {self.safe_identifier(c) for c in columns}
            missing = expected_names - existing_names
            if missing:
                raise ValueError(
                    "Staging table already exists with a different schema. "
                    f"Missing columns: {sorted(missing)}. Use a new versioned "
                    "staging table name for a changed source schema."
                )
        return table_name
