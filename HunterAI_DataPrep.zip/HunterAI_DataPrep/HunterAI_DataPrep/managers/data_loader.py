import re
from sqlalchemy import text


class DataLoader:
    @staticmethod
    def _quote_identifier(identifier):
        if not re.fullmatch(r"[A-Za-z0-9_]+", str(identifier)):
            raise ValueError(f"Unsafe SQL identifier: {identifier}")
        return "`" + identifier + "`"

    def load_dataframe(self, engine, dataframe, target_table, chunk_size=1000):
        if dataframe.empty:
            return 0
        q_table = self._quote_identifier(target_table)
        columns = list(dataframe.columns)
        quoted_columns = [self._quote_identifier(c) for c in columns]
        placeholders = [f":p{i}" for i in range(len(columns))]
        insert_sql = text(
            f"INSERT INTO {q_table} "
            f"({', '.join(quoted_columns)}) "
            f"VALUES ({', '.join(placeholders)})"
        )

        inserted = 0
        records = dataframe.to_dict(orient="records")
        for start in range(0, len(records), chunk_size):
            chunk = records[start:start + chunk_size]
            params = [
                {f"p{i}": row[col] for i, col in enumerate(columns)}
                for row in chunk
            ]
            with engine.begin() as conn:
                conn.execute(insert_sql, params)
            inserted += len(chunk)
        return inserted

    @staticmethod
    def _safe_source_column(value):
        import re
        cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", str(value)).strip("_").lower()
        if not cleaned:
            raise ValueError(f"Invalid source column name: {value}")
        if cleaned[0].isdigit():
            cleaned = "c_" + cleaned
        return cleaned[:64]

    def load_raw_dataframe(self, engine, dataframe, table_name, batch_id,
                           chunk_size=1000):
        if dataframe.empty:
            return 0
        q_table = self._quote_identifier(table_name)
        source_columns = [str(c) for c in dataframe.columns]
        columns = [self._safe_source_column(c) for c in source_columns]
        if len(set(columns)) != len(columns):
            raise ValueError("Source headers collide after SQL-safe normalization")
        q_columns = [self._quote_identifier(c) for c in columns]
        all_columns = q_columns + ["`_batch_id`"]
        placeholders = [f":p{i}" for i in range(len(columns))] + [":batch_id"]
        insert_sql = text(
            f"INSERT INTO {q_table} ({', '.join(all_columns)}) "
            f"VALUES ({', '.join(placeholders)})"
        )
        records = dataframe.to_dict(orient="records")
        inserted = 0
        for start in range(0, len(records), chunk_size):
            chunk = records[start:start + chunk_size]
            params = []
            for row in chunk:
                item = {
                    f"p{i}": row[source_col]
                    for i, source_col in enumerate(source_columns)
                }
                item["batch_id"] = batch_id
                params.append(item)
            with engine.begin() as conn:
                conn.execute(insert_sql, params)
            inserted += len(chunk)
        return inserted
