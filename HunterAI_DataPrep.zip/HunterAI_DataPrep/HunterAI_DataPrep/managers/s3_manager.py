from pathlib import Path
from urllib.parse import urlparse
import boto3
from config import settings


class S3Manager:
    def __init__(self, region_name=None):
        self.client = boto3.client(
            "s3",
            region_name=region_name or settings.AWS_REGION
        )

    @staticmethod
    def parse_s3_location(bucket, s3_path):
        # Accept either an object key or a full s3://bucket/key URI.
        if s3_path.startswith("s3://"):
            parsed = urlparse(s3_path)
            return parsed.netloc, parsed.path.lstrip("/")
        return bucket, s3_path.lstrip("/")

    def download_file(self, bucket, s3_path, local_path):
        actual_bucket, object_key = self.parse_s3_location(bucket, s3_path)
        if not actual_bucket or not object_key:
            raise ValueError("S3 bucket and object key are required")
        local_path = Path(local_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        self.client.download_file(actual_bucket, object_key, str(local_path))
        return local_path
