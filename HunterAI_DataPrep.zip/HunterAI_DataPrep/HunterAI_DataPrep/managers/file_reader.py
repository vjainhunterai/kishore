import csv
from pathlib import Path
import pandas as pd


class FileReader:
    SUPPORTED = {".csv", ".txt", ".xlsx", ".xls"}

    @staticmethod
    def _detect_delimiter(file_path):
        # Fallback automatic detection. If your existing delimiter detector
        # is available as a Python function, replace this method with that call.
        with open(file_path, "r", encoding="utf-8-sig", errors="replace") as f:
            sample = f.read(65536)
        try:
            return csv.Sniffer().sniff(sample, delimiters=",|;\\t").delimiter
        except csv.Error:
            return ","

    def read(self, file_path):
        path = Path(file_path)
        extension = path.suffix.lower()
        if extension not in self.SUPPORTED:
            raise ValueError(f"Unsupported file format: {extension}")

        if extension in {".csv", ".txt"}:
            delimiter = self._detect_delimiter(path)
            df = pd.read_csv(
                path,
                sep=delimiter,
                dtype=str,
                keep_default_na=False,
                encoding="utf-8-sig",
                on_bad_lines="error",
            )
        elif extension == ".xlsx":
            df = pd.read_excel(path, dtype=str, keep_default_na=False, engine="openpyxl")
        else:
            df = pd.read_excel(path, dtype=str, keep_default_na=False, engine="xlrd")

        if len(df.columns) == 0:
            raise ValueError("Input file has no header columns")
        if any(str(c).strip() == "" for c in df.columns):
            raise ValueError("Input file contains a blank header")
        if len(set(map(str, df.columns))) != len(df.columns):
            raise ValueError("Input file contains duplicate column names")

        # Normalize column labels only; source values remain strings.
        df.columns = [str(c).strip() for c in df.columns]
        if len(set(df.columns)) != len(df.columns):
            raise ValueError("Duplicate headers after trimming whitespace")
        return df
