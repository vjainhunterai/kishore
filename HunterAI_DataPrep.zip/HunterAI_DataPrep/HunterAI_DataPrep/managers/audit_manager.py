from sqlalchemy import text


class AuditManager:
    ALLOWED_PROCESSES = {"DATAPREP", "ETL", "ANOMALY"}

    def __init__(self, engine):
        self.engine = engine

    def start_audit(self, metadata_id, pipeline_run_id, batch_id,
                    process_name, step_name):
        if process_name not in self.ALLOWED_PROCESSES:
            raise ValueError(f"Invalid process_name: {process_name}")

        # Locking the metadata row serializes attempt-number allocation for
        # this metadata record, including concurrent retries.
        lock_sql = text("""
            SELECT metadata_id
              FROM joblog_metadata.dataprep_metadata
             WHERE metadata_id = :metadata_id
             FOR UPDATE
        """)
        attempt_sql = text("""
            SELECT COALESCE(MAX(attempt_no), 0) + 1
              FROM joblog_metadata.dataprep_audit
             WHERE pipeline_run_id = :pipeline_run_id
               AND process_name = :process_name
               AND step_name = :step_name
        """)
        insert_sql = text("""
            INSERT INTO joblog_metadata.dataprep_audit
            (metadata_id, pipeline_run_id, batch_id, process_name,
             step_name, attempt_no, status, start_time)
            VALUES
            (:metadata_id, :pipeline_run_id, :batch_id, :process_name,
             :step_name, :attempt_no, 'RUNNING', CURRENT_TIMESTAMP(3))
        """)
        with self.engine.begin() as conn:
            if conn.execute(lock_sql, {"metadata_id": metadata_id}).first() is None:
                raise ValueError(f"Metadata record not found: {metadata_id}")
            attempt_no = conn.execute(attempt_sql, {
                "pipeline_run_id": pipeline_run_id,
                "process_name": process_name,
                "step_name": step_name,
            }).scalar_one()
            result = conn.execute(insert_sql, {
                "metadata_id": metadata_id,
                "pipeline_run_id": pipeline_run_id,
                "batch_id": batch_id,
                "process_name": process_name,
                "step_name": step_name,
                "attempt_no": attempt_no,
            })
            return {"audit_id": result.lastrowid, "attempt_no": attempt_no}

    def complete_audit(self, audit_id, input_records=0,
                       success_records=0, rejected_records=0):
        sql = text("""
            UPDATE joblog_metadata.dataprep_audit
               SET status = 'SUCCESS', end_time = CURRENT_TIMESTAMP(3),
                   input_records = :input_records,
                   success_records = :success_records,
                   rejected_records = :rejected_records,
                   error_message = NULL
             WHERE audit_id = :audit_id AND status = 'RUNNING'
        """)
        with self.engine.begin() as conn:
            result = conn.execute(sql, {
                "audit_id": audit_id,
                "input_records": input_records,
                "success_records": success_records,
                "rejected_records": rejected_records,
            })
            if result.rowcount != 1:
                raise ValueError(f"Audit {audit_id} not found or not RUNNING")

    def fail_audit(self, audit_id, error_message, input_records=0,
                   success_records=0, rejected_records=0):
        sql = text("""
            UPDATE joblog_metadata.dataprep_audit
               SET status = 'FAILED', end_time = CURRENT_TIMESTAMP(3),
                   input_records = :input_records,
                   success_records = :success_records,
                   rejected_records = :rejected_records,
                   error_message = :error_message
             WHERE audit_id = :audit_id AND status = 'RUNNING'
        """)
        with self.engine.begin() as conn:
            result = conn.execute(sql, {
                "audit_id": audit_id,
                "input_records": input_records,
                "success_records": success_records,
                "rejected_records": rejected_records,
                "error_message": str(error_message)[:60000],
            })
            if result.rowcount != 1:
                raise ValueError(f"Audit {audit_id} not found or not RUNNING")
