from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import datetime
import pandas as pd


REQUIRED_MAPPING_COLUMNS = {
    "source_column", "target_column", "transformation",
    "target_data_type", "mandatory_flag"
}


class MappingManager:
    def read_mapping(self, mapping_file_path):
        if not mapping_file_path:
            raise ValueError("mapping_file_path is missing in metadata")
        mapping_df = pd.read_excel(
            Path(mapping_file_path),
            dtype=str,
            keep_default_na=False,
            engine="openpyxl",
        )
        mapping_df.columns = [str(c).strip().lower() for c in mapping_df.columns]
        missing = REQUIRED_MAPPING_COLUMNS - set(mapping_df.columns)
        if missing:
            raise ValueError(f"Mapping Excel missing columns: {sorted(missing)}")

        mapping = mapping_df[list(REQUIRED_MAPPING_COLUMNS)].to_dict("records")
        if not mapping:
            raise ValueError("Mapping Excel contains no mapping rows")
        return mapping

    @staticmethod
    def transform_value(value, transformation, target_data_type):
        value = "" if value is None else str(value)
        transform = (transformation or "").strip().lower()
        dtype = (target_data_type or "string").strip().lower()

        if transform in {"", "none", "no_transformation"}:
            result = value
        elif transform in {"trim", "strip"}:
            result = value.strip()
        elif transform == "upper":
            result = value.upper()
        elif transform == "lower":
            result = value.lower()
        else:
            raise ValueError(f"Unsupported transformation: {transformation}")

        if result == "":
            return None

        if dtype in {"string", "varchar", "text", "char"}:
            return result
        if dtype in {"int", "integer", "bigint"}:
            return int(result)
        if dtype in {"decimal", "numeric"}:
            try:
                return Decimal(result)
            except InvalidOperation as exc:
                raise ValueError(f"Invalid decimal value: {result}") from exc
        if dtype in {"float", "double"}:
            return float(result)
        if dtype == "date":
            return datetime.strptime(result, "%Y-%m-%d").date()
        if dtype in {"datetime", "timestamp"}:
            return datetime.fromisoformat(result)
        if dtype in {"boolean", "bool"}:
            normalized = result.strip().lower()
            if normalized in {"true", "1", "y", "yes"}:
                return 1
            if normalized in {"false", "0", "n", "no"}:
                return 0
            raise ValueError(f"Invalid boolean value: {result}")
        raise ValueError(f"Unsupported target_data_type: {target_data_type}")

    def apply_mapping(self, source_df, mapping):
        source_lookup = {str(c).strip().lower(): c for c in source_df.columns}
        output = {}
        for item in mapping:
            source_name = str(item["source_column"]).strip()
            target_name = str(item["target_column"]).strip()
            if not source_name or not target_name:
                raise ValueError("source_column and target_column cannot be blank")
            lookup_key = source_name.lower()
            if lookup_key not in source_lookup:
                raise ValueError(f"Source column not found in file: {source_name}")
            actual_source = source_lookup[lookup_key]
            mandatory = str(item["mandatory_flag"]).strip().upper() in {"Y", "YES", "TRUE", "1"}
            values = []
            for row_number, value in enumerate(source_df[actual_source], start=2):
                try:
                    transformed = self.transform_value(
                        value, item["transformation"], item["target_data_type"]
                    )
                    if mandatory and transformed is None:
                        raise ValueError("Mandatory value is blank")
                    values.append(transformed)
                except Exception as exc:
                    raise ValueError(
                        f"Mapping error at Excel row {row_number}, "
                        f"source column '{source_name}': {exc}"
                    ) from exc
            if target_name in output:
                raise ValueError(f"Duplicate target_column in mapping: {target_name}")
            output[target_name] = values
        return pd.DataFrame(output)
