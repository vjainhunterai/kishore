from sqlalchemy import text


class MetadataManager:
    def __init__(self, engine):
        self.engine = engine

    def claim_metadata(self, customer_name: str, batch_id: str):
        # Conditional UPDATE is atomic: only one worker can change an eligible row.
        claim_sql = text("""
            UPDATE joblog_metadata.dataprep_metadata
               SET status = 'PROCESSING', active_flag = 'Y'
             WHERE customer_name = :customer_name
               AND batch_id = :batch_id
               AND active_flag = 'Y'
               AND status IN ('PENDING', 'FAILED')
        """)
        fetch_sql = text("""
            SELECT metadata_id, customer_name, project_name, file_name,
                   s3_bucket, s3_path, mapping_file_path, file_size_bytes,
                   file_format, file_checksum, active_flag, status, batch_id
              FROM joblog_metadata.dataprep_metadata
             WHERE customer_name = :customer_name
               AND batch_id = :batch_id
               AND status = 'PROCESSING'
               AND active_flag = 'Y'
        """)
        with self.engine.begin() as conn:
            result = conn.execute(claim_sql, {
                "customer_name": customer_name, "batch_id": batch_id
            })
            if result.rowcount != 1:
                return None
            row = conn.execute(fetch_sql, {
                "customer_name": customer_name, "batch_id": batch_id
            }).mappings().first()
            return dict(row) if row else None

    def update_status(self, metadata_id: int, status: str, active_flag: str):
        allowed_statuses = {"PENDING", "PROCESSING", "COMPLETED", "FAILED"}
        if status not in allowed_statuses:
            raise ValueError(f"Invalid metadata status: {status}")
        if active_flag not in {"Y", "N"}:
            raise ValueError("active_flag must be Y or N")
        sql = text("""
            UPDATE joblog_metadata.dataprep_metadata
               SET status = :status, active_flag = :active_flag
             WHERE metadata_id = :metadata_id
        """)
        with self.engine.begin() as conn:
            result = conn.execute(sql, {
                "metadata_id": metadata_id,
                "status": status,
                "active_flag": active_flag,
            })
            if result.rowcount != 1:
                raise ValueError(f"Metadata record not found: {metadata_id}")
