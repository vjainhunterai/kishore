import re
from sqlalchemy import URL, create_engine, text
from config import settings


class DatabaseConnection:
    def __init__(self, database_name: str):
        if not re.fullmatch(r"[A-Za-z0-9_]+", database_name or ""):
            raise ValueError("Invalid database name. Use letters, numbers and underscore.")
        self.database_name = database_name
        self.engine = None

    def connect(self):
        url = URL.create(
            drivername="mysql+pymysql",
            username=settings.DB_USER,
            password=settings.DB_PASSWORD,
            host=settings.DB_HOST,
            port=settings.DB_PORT,
            database=self.database_name,
            query={"charset": "utf8mb4"},
        )
        self.engine = create_engine(
            url,
            pool_pre_ping=True,
            pool_recycle=3600,
            future=True,
        )
        # Verify connectivity
        with self.engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return self.engine

    def close(self):
        if self.engine is not None:
            self.engine.dispose()
            self.engine = None
