import argparse
import logging
import uuid
from pathlib import Path

from config import settings
from database.db_connection import DatabaseConnection
from managers.metadata_manager import MetadataManager
from managers.audit_manager import AuditManager
from managers.s3_manager import S3Manager
from managers.file_reader import FileReader
from managers.schema_manager import SchemaManager
from managers.mapping_manager import MappingManager
from managers.data_loader import DataLoader


LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "dataprep.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("HunterAI_DataPrep")


def run_audited_step(audit_manager, metadata, pipeline_run_id,
                     step_name, function):
    audit = audit_manager.start_audit(
        metadata_id=metadata["metadata_id"],
        pipeline_run_id=pipeline_run_id,
        batch_id=metadata["batch_id"],
        process_name="DATAPREP",
        step_name=step_name,
    )
    audit_id = audit["audit_id"]
    try:
        result = function()
        # Each step may return counts; defaults are zero.
        counts = result if isinstance(result, dict) else {}
        audit_manager.complete_audit(
            audit_id,
            input_records=counts.get("input_records", 0),
            success_records=counts.get("success_records", 0),
            rejected_records=counts.get("rejected_records", 0),
        )
        return result
    except Exception as exc:
        try:
            audit_manager.fail_audit(audit_id, str(exc))
        except Exception:
            logger.exception("Could not mark audit %s as FAILED", audit_id)
        raise


def main(customer_name, batch_id):
    settings.validate_settings()
    pipeline_run_id = str(uuid.uuid4())
    metadata_db = DatabaseConnection("joblog_metadata")
    customer_db = None
    metadata_id = None
    metadata_manager = None
    audit_manager = None
    metadata = None

    try:
        logger.info(
            "DataPrep started | customer=%s | batch=%s | run=%s",
            customer_name, batch_id, pipeline_run_id
        )

        metadata_engine = metadata_db.connect()
        metadata_manager = MetadataManager(metadata_engine)
        audit_manager = AuditManager(metadata_engine)

        metadata = metadata_manager.claim_metadata(customer_name, batch_id)
        if metadata is None:
            logger.warning("No eligible metadata row found; already claimed or not pending/failed.")
            return

        metadata_id = metadata["metadata_id"]

        def connect_customer_database():
            nonlocal customer_db
            customer_db = DatabaseConnection(customer_name)
            return customer_db.connect()

        customer_engine = run_audited_step(
            audit_manager, metadata, pipeline_run_id,
            "CUSTOMER_DB_CONNECT", connect_customer_database
        )

        temp_dir = settings.TEMP_DIR / customer_name / batch_id
        temp_dir.mkdir(parents=True, exist_ok=True)
        local_file = temp_dir / Path(metadata["file_name"]).name

        s3_manager = S3Manager()
        file_reader = FileReader()
        schema_manager = SchemaManager()
        mapping_manager = MappingManager()
        data_loader = DataLoader()

        def download():
            s3_manager.download_file(
                metadata["s3_bucket"], metadata["s3_path"], local_file
            )
            return {}

        run_audited_step(
            audit_manager, metadata, pipeline_run_id, "S3_DOWNLOAD", download
        )

        def read_source():
            df = file_reader.read(local_file)
            return {
                "input_records": len(df),
                "success_records": len(df),
                "dataframe": df,
            }

        source_result = run_audited_step(
            audit_manager, metadata, pipeline_run_id, "FILE_READ", read_source
        )
        source_df = source_result["dataframe"]
        input_count = len(source_df)

        def create_staging():
            staging_table = schema_manager.create_or_validate_staging_table(
                customer_engine, metadata["file_name"], source_df.columns
            )
            inserted = data_loader.load_raw_dataframe(
                customer_engine, source_df, staging_table,
                metadata["batch_id"], settings.CHUNK_SIZE
            )
            return {
                "input_records": input_count,
                "success_records": inserted,
                "staging_table": staging_table,
            }

        staging_result = run_audited_step(
            audit_manager, metadata, pipeline_run_id, "STAGING_LOAD", create_staging
        )

        def apply_mapping_and_load():
            mapping = mapping_manager.read_mapping(metadata["mapping_file_path"])
            mapped_df = mapping_manager.apply_mapping(source_df, mapping)
            loaded = data_loader.load_dataframe(
                customer_engine, mapped_df, settings.TARGET_TABLE,
                settings.CHUNK_SIZE
            )
            return {
                "input_records": input_count,
                "success_records": loaded,
            }

        mapping_result = run_audited_step(
            audit_manager, metadata, pipeline_run_id,
            "MAPPING_AND_TARGET_LOAD", apply_mapping_and_load
        )

        metadata_manager.update_status(metadata_id, "COMPLETED", "N")
        logger.info(
            "DataPrep completed | metadata_id=%s | staging_table=%s | "
            "input=%s | loaded=%s",
            metadata_id,
            staging_result["staging_table"],
            input_count,
            mapping_result["success_records"],
        )

    except Exception as exc:
        logger.exception("DataPrep failed")
        if metadata_id is not None and metadata_manager is not None:
            try:
                metadata_manager.update_status(metadata_id, "FAILED", "Y")
            except Exception:
                logger.exception("Could not update metadata status to FAILED")
        raise

    finally:
        if customer_db is not None:
            customer_db.close()
        metadata_db.close()
        logger.info("Database connections closed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HunterAI DataPrep V1")
    parser.add_argument("--customer_name", required=True)
    parser.add_argument("--batch_id", required=True)
    args = parser.parse_args()
    main(args.customer_name, args.batch_id)
