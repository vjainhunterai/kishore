# HunterAI DataPrep V1

A modular Python V1 for downloading a customer file from S3, reading CSV/TXT/XLSX/XLS,
loading raw values into a dynamic staging table, applying an Excel mapping, and loading
the standardized target table.

## Architecture assumptions

- Central metadata and audit tables are in `joblog_metadata`.
- The customer database name is exactly `customer_name`.
- `dataprep_metadata` contains one row per batch.
- `s3_path` is either an S3 object key or a full `s3://bucket/key` URI.
- Mapping workbook is accessible to the Python process at `mapping_file_path`.
  If it is stored in S3, download it first or extend S3Manager to download it.
- Customer database already contains the standardized target table, default `temp_ap_inv`.
- The target table columns must match `target_column` names and accept the converted values.
- Source values are loaded as text in the staging table to preserve leading zeros.
- Existing delimiter detection can replace `FileReader._detect_delimiter()`.

## Mapping Excel

Use one worksheet with exactly these required headers (case-insensitive):

| source_column | target_column | transformation | target_data_type | mandatory_flag |
|---|---|---|---|---|
| Invoice Number | invoice_number | trim | string | Y |
| Invoice Date | invoice_date | trim | date | Y |
| Amount | invoice_amount | trim | decimal | N |

Supported transformations: blank/none, `trim`, `strip`, `upper`, `lower`.

Supported target types: `string`, `varchar`, `text`, `char`, `int`, `integer`,
`bigint`, `decimal`, `numeric`, `float`, `double`, `date` (YYYY-MM-DD),
`datetime`, `timestamp` (ISO format), `boolean`, `bool`.

## Setup

1. Create/activate a Python virtual environment.
2. Install dependencies:

   `pip install -r requirements.txt`

3. Copy `.env.example` to `.env` and fill in MySQL connection details.
4. Configure AWS credentials using an EC2 instance role, AWS profile, or environment.
5. Ensure the application MySQL user can access `joblog_metadata` and the intended
   customer databases.
6. Ensure `temp_ap_inv` exists in each customer database with columns matching the
   mapping workbook.

## Run

`python main.py --customer_name customer_abc --batch_id BATCH_001`

## Important V1 limitations / operational notes

- This version processes each input file in memory using pandas; large-file chunked
  reading is a later enhancement. Inserts are batched.
- The mapping workbook path is treated as a local/shared filesystem path. S3 mapping
  workbook download is not yet implemented.
- A failed run leaves any already-inserted staging/target rows in place. Before retrying,
  use a batch-aware target design or cleanup strategy to avoid duplicate target rows.
- `STAGING_LOAD` currently uses a table name derived from the file name. If a different
  source schema arrives for the same file-derived table, it stops rather than altering
  the existing table.
- The metadata claim is atomic. Do not manually set PROCESSING rows back to PENDING
  while a worker may still be running.
- The current claim does not implement a lease/timeout for workers that crash after
  claiming. Add a stale-processing recovery policy before production deployment.
- No DQ or anomaly execution is included here; those remain separate jobs.
- Do not expose `.env` or AWS credentials in source control.
