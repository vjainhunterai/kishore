import os
from pathlib import Path
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / ".env")

DB_HOST = os.getenv("DB_HOST")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")
TEMP_DIR = Path(os.getenv("TEMP_DIR", str(PROJECT_ROOT / "tmp")))
TARGET_TABLE = os.getenv("TARGET_TABLE", "temp_ap_inv")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1000"))

def validate_settings():
    missing = [
        key for key, value in {
            "DB_HOST": DB_HOST,
            "DB_USER": DB_USER,
            "DB_PASSWORD": DB_PASSWORD,
        }.items() if not value
    ]
    if missing:
        raise RuntimeError("Missing .env settings: " + ", ".join(missing))
    if CHUNK_SIZE < 1:
        raise RuntimeError("CHUNK_SIZE must be greater than zero")
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
